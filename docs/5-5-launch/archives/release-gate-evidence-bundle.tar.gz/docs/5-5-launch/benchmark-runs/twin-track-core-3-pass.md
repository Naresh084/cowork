# Twin-Track Core 3-Pass Benchmark

- Generated: 2026-02-12T23:09:06.689Z
- Suite: twin-track-core
- Profile: release
- Runs: manual-pass-1, manual-pass-2, manual-pass-3
- Benchmark score (pass 3): 0.9405
- Feature checklist score (pass 3): 1.0000
- Final score (pass 3): 0.9584
- Dimensions passing (pass 3): yes

